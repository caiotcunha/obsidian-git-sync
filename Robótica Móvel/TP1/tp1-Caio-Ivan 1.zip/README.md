# TP01Robotica
Caio Teles Cunha 2020006434
Ivan Vilaça 2021421931

Para rodar basta abrir a cena no coppelia e executar as células do notebook.
